import { Item } from "./item.interface";

export interface Sezioni {
    label: string,
    items: Item[]
}
export interface Credenziali {
    id?: number,
    user?: string,
    pass?: string,
    ruolo: string
}
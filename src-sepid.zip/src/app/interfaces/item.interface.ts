export interface Item {
    id?:number;
    nome: string;
    descrizione: string,
    prezzo: number;
    disponibile: boolean
}
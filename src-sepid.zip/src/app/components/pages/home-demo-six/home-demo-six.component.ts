import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-demo-six',
  templateUrl: './home-demo-six.component.html',
  styleUrls: ['./home-demo-six.component.scss']
})
export class HomeDemoSixComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-a-table-page',
  templateUrl: './book-a-table-page.component.html',
  styleUrls: ['./book-a-table-page.component.scss']
})
export class BookATablePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-demo-five',
  templateUrl: './home-demo-five.component.html',
  styleUrls: ['./home-demo-five.component.scss']
})
export class HomeDemoFiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

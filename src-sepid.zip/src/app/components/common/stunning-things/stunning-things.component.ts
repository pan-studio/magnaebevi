import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stunning-things',
  templateUrl: './stunning-things.component.html',
  styleUrls: ['./stunning-things.component.scss']
})
export class StunningThingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
